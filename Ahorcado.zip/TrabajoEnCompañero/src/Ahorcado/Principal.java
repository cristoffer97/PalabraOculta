package Ahorcado;

import java.util.Scanner;

import BuscarPalabra.Palabra;
import BuscarPalabra.Partida;

import java.nio.file.FileSystemNotFoundException;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Random;

public class Principal {

	//vector palabras secretas
	//public static final String[] vPalabrasSecretas=	{"traza","C�mara","array","sifon","Teclado","Monitor","mesa","raton","bocadillo","proyector","frio","alumno"};
	public static final String[] vPalabrasSecretas=	{"kraken","pegaso","hydra"};
	//vector de indices de palabra con las que ya hemos jugado para evitar repeticiones
	public static boolean[] vIndices = new boolean [vPalabrasSecretas.length];
	
	//maximo intentos
public static final int maxIntentos = 5;

//contadores de partidas
public static int victorias=0, derrotas=0;

//devuelve una palabra aleatoria del vector de palabras secretas
public static String nuevaPalabra() {
	if ((victorias+derrotas)%vPalabrasSecretas.length == 0) {
		for(int i=0; i<vPalabrasSecretas.length; i++) {
			vIndices[i]=false;
		}
	}
	int i=0;
	do {
		i=new Random().nextInt (vPalabrasSecretas.length);
	} while(vIndices[i]== true);
	vIndices[i]=true;
	return vPalabrasSecretas[i];
}

//lee un caracter por teclado, comprueba que es una tecla y la devuelve en minusculas

public static char leerLetra(Scanner in) {
	char l= ' ';
	do {
		try {
			System.out.print("introduzca una letra");
			l= in.nextLine().toLowerCase().charAt(0);
		} catch (InputMismatchException ine) {
			System.out.println("Opcion no v�lida.\n");
		}
	}while (!Character.isLetter(l));
	System.out.println();
	return l;
}

//Muestra el estado actual del juego sustituyendo las letras ocultas por '-'


public static void mostrarEstadoPartida(char[] palabra, char[] fallos){
System.out.print("palabra: \t");
for (int i=0; i<palabra.length; i++) {
	if((int)palabra[i]==0) {
		System.out.print("-");	
	}else {
		System.out.println(palabra[i]+" ");
	}
}
System.out.print("\nFallos: \t");
for (int i=0; i<fallos.length; i++) {
	if((int)fallos[i]==0) {
		System.out.println("_");
	}else {
		System.out.println(fallos[i]+" ");
	}
}
System.out.println();
}

//la palabra devuelve TRUE si el jugador obtiene una victoria false sino

public static boolean partida (Scanner in) {
	final String palabraSecreta=nuevaPalabra();
	char[] vPalabra= new char [palabraSecreta.length()];
	char[] vLetras= new char [maxIntentos];
	int fallos=0;
	char letra;
	boolean fin = false, letraCorrecta;
	
	//bucle de jugadas
	do {
		letraCorrecta=false;
		mostrarEstadoPartida(vPalabra, vLetras);
		System.out.println("Intentos restantes: "+(maxIntentos-fallos));
		letra=leerLetra(in);
	for (int i=0; i<palabraSecreta.length(); i++) {
		if(palabraSecreta.charAt(i)==letra && vPalabra[i]!=letra) {
			vPalabra[i]=letra;
			letraCorrecta=true; }
	}
	if(letraCorrecta) {
		fin=palabraSecreta.equals(String.copyValueOf(vPalabra));
	}else {
		vLetras[fallos]=letra;
		fallos++;
	}		
} while (!fin && fallos<maxIntentos);
	mostrarEstadoPartida(vPalabra, vLetras);
	if (fin) {
		System.out.println("Victoria Magistral");
	}else{
		System.out.println("Derrota eres muy malo, Pedazo de Ceporro vuelve a estudiar");
	}
	System.out.println("La palabra secreta era: " +palabraSecreta+"\n");
	return fin;
	}



//partidos	
	
	
	public static void main (String[] args) {
		//Palabra 1
		String valor1="kraken";
		char [] palabra_Primaria = valor1.toCharArray();
		boolean[] boolean1 = new boolean[valor1.length()];
		Palabra palabra1=new Palabra(valor1, palabra_Primaria, boolean1);
		//Palabra 2
		String valor2="Pegaso";
		char [] palabra_Segunda = valor2.toCharArray();
		boolean[] boolean2 = new boolean[valor2.length()];
		Palabra palabra2=new Palabra(valor2, palabra_Segunda, boolean2);
		//Palabra 3
		String valor3="Hydra";
		char [] palabra_Tercera = valor3.toCharArray();
		boolean[] boolean3 = new boolean[valor3.length()];
		Palabra palabra3=new Palabra(valor3, palabra_Tercera, boolean3);
		//Array de objetos de palabras
		Palabra[] palabras=new Palabra[3];
		palabras[0]=palabra1;
		palabras[1]=palabra2;
		palabras[2]=palabra3;

		//Objeto de partida
		Partida Partida1=new Partida(LocalDate.of(2022, 01, 24), "Federico", palabras, 3);
		
		
		
		
		Scanner input=new Scanner(System.in);
		int opcion=0;
		do {
			System.out.println("MENU");
			System.out.println("1.jugar partida");
			System.out.println("2. Ver estadisticas");
			System.out.println("0. salir");
				try {
					System.out.println("selecccionar opcion:");
					opcion=input.nextInt();
				}catch (InputMismatchException ime) {
					opcion=100;
				}
				input.nextLine();
				switch (opcion) {
					case 1:
						if (partida(input)) {
							victorias++;
						}else {
							derrotas++;
						}
						break;
					case 2:
					System.out.println("victorias: "+victorias);
					System.out.println("Derrotas:"+derrotas+"\n");
					break;
					case 0:
						System.out.println("Fin de programa \n");
						break;
						default:
							System.out.println("opcion no valida \n");
							break;
				}
		} while (opcion!=0);
		input.close();
				}

	}
